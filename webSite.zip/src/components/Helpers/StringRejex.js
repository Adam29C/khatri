export const nameRejext = (string) => {
  return string.toLowerCase().replace(/\s+/g, "");
};

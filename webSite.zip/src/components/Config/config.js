// export const base_url = "http://localhost:5000/"
// export const base_url = "http://51.20.125.209:5000/"
// export const base_url = "http://16.171.241.112:5000/"
// export const base_url = "http://13.51.64.99:5000/"
// export const base_url = "http://16.170.215.79:5000/"

export const base_url = "http://15.237.142.14:5000/"
